#ifndef AGENT_H
#define AGENT_H

void agent_process(int client_fd);

#endif // AGENT_H
